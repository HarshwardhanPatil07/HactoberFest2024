# Projeto-jogo-em-C-ASCII-UEL
Projeto de Téc. de Programação da UEL - Turma Ciência da Computação 2019. Desenvolvimento de jogo em C.


## README DO PROJETO

### JOGO - PACMAN EM C USANDO ASCII

#### Grupo formado pelos alunos:
- Gabriel H. N. Espindola;
- Henrique Tsuneda;
- Lucca Motta;
- João Gabriel;

#### PROPOSTA
 - Aplicar os conceitos de programação ministrados no primeiro semestre em diferentes ambientes dentro de um jogo.

#### FUNCIONAMENTO DO JOGO
O jogo a ser criado é baseado no famoso jogo PACMAN no qual o personagem principal tem como objetivo capturar todos os pontos
espalhados pelo mapa. Para dificultar o objetivo do jogador, existem 4 fantasmas que tentam "matar" o personagem principal
(jogador), entretanto existe um tipo de ponto que possibilita o jogador "matar" os fantasmas, mas após alguns segundos os fantasmas voltam.
Ao comer todos os pontos do mapa sem morrer mais do que 3 vezes o jogo é finalizado como vitória.

#### REGRAS, PONTUAÇÕES E PADRÕES
- **Geral**: 
	- 1 jogador
	- 1 nível;
	- 4 fantasmas;
	- Dimensão do mapa de 30x30 (não sei exatamente qual a unidade de medida);
	
- **Regras**
	- O jogador começa com apenas 3 vidas, não podendo ser acrestado mais que isso.
	- A cada super ponto coletado o jogador tem 10 seg. para eliminar os fantasmas, no qual irão fugir do pacman. Após passado esses 10 seg. o pacman volta a ser caçado.
	-
- **Pontuações**:
	-


### Descrição das funções do jogo:
- **Em breve**
