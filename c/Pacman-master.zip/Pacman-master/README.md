# Pacman
A simple PACMAN game developed in C Graphics. Complied and ran in TurboC++.

pacman.h includes links to other header files.

## And yeah TurboC++ runs on borland compiler! HOME of old depricated Graphics.h!

### I have archieved the code cause its trully copied from web and modified!
